package com.cognizant.OrderManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriComponentsBuilder;

import com.cognizant.OrderManagement.Dao.UserService;
import com.cognizant.OrderManagement.model.User;



@Controller
@RequestMapping("user")
@CrossOrigin(origins = {"http://localhost:4200"})
public class UserController {

	 @Autowired
	    private UserService userService;

	@PostMapping("register")
	public ResponseEntity<Void> createArticle(@RequestBody User user, UriComponentsBuilder builder) {
        
       System.out.println("df");
       Boolean f = userService.save(user);
       System.out.println(f);
       if(f==false)
       {
    	   return new ResponseEntity<Void>(HttpStatus.valueOf(202));
       }
        HttpHeaders headers = new HttpHeaders();
        //headers.setLocation(builder.path("/article?id={id}").buildAndExpand(article.getArticleId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
}
