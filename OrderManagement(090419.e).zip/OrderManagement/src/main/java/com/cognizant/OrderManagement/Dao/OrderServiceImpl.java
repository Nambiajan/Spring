package com.cognizant.OrderManagement.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.model.UserOrder;
import com.cognizant.OrderManagement.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private OrderRepository orderRepository;


	public UserOrder addOrder(Item i) {
		// TODO Auto-generated method stub
		 Item item =itemService.findById(i.getId());
		 UserOrder Order = new UserOrder();
		 Order.setQuantity(i.getQuantity());
		 
		 Order.setTprice(item.getPrice()*i.getQuantity());
		 
		 Order.setItem(item);
	     
		 orderRepository.save(Order);
		 return Order;
	}

	@Override
	public UserOrder findOrder(Cart cart , Item i) {
		// TODO Auto-generated method stub
		  UserOrder Order = new UserOrder();
		  Item item =itemService.findById(i.getId());
		  int f=0;
		  for(UserOrder o : cart.getOrders())
		  {
			  if(o.getItem().getId()==i.getId())
			  {
				  f=1;
				  
				  o.setQuantity(i.getQuantity()+o.getQuantity());
				  o.setTprice(item.getPrice()*o.getQuantity());
			  }
		  }
		  
		  if(f==0)
		  {
			  return addOrder(i);
		  }
		  else{
		   orderRepository.save(Order);
		    return Order;
		  }
	}

	
	

}
