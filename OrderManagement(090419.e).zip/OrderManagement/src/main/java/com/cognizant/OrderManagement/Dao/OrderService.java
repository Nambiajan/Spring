package com.cognizant.OrderManagement.Dao;

import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.model.UserOrder;

public interface OrderService {

	

	UserOrder addOrder(Item item);

	UserOrder findOrder(Cart cart, Item item);



	

}
