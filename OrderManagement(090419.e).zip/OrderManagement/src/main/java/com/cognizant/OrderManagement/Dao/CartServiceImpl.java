package com.cognizant.OrderManagement.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.model.UserOrder;
import com.cognizant.OrderManagement.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	CartRepository cartRepository;
	@Autowired
	private ItemService itemService;
	@Autowired
	private OrderService orderService;
	
	
	public Cart findById(Integer id)
	{
		
		return cartRepository.getOne(id);
	}

	@Override
	public void save(Cart cart) {
		// TODO Auto-generated method stub
		cartRepository.save(cart);
	}

	@Override
	public void addToCart(Item i) {
		// TODO Auto-generated method stub
		  Cart cart = findById(1);
		  
		  if(cart.getOrders().size()==0)
		  {
			 cart.getOrders().add(orderService.addOrder(i));
		  }
		  else
		  {
			 cart.getOrders().add(orderService.findOrder(cart,i));
		  }
		  save(cart);
	}
	


}
