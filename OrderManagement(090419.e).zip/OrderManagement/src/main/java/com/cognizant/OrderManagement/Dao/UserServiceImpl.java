package com.cognizant.OrderManagement.Dao;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cognizant.OrderManagement.model.User;
import com.cognizant.OrderManagement.repository.UserRepository;



@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
   
   

    @Override
    public boolean save(User user) {
        
    	if(findByUsername(user.getUsername())==null)
    	{
    	  user.setRole("user");
    	
          userRepository.save(user);
          return true;
    	}
    	else
    		return false;
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}
