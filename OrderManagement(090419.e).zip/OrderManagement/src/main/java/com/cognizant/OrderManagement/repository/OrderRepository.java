package com.cognizant.OrderManagement.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.OrderManagement.model.UserOrder;
public interface OrderRepository extends JpaRepository<UserOrder,Integer>{

}
