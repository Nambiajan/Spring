package com.cognizant.OrderManagement.Dao;

import com.cognizant.OrderManagement.model.User;

public interface UserService {

	 boolean save(User user);

	 User findByUsername(String username);
}
