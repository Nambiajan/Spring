package com.cognizant.OrderManagement.Dao;

import java.util.List;

import com.cognizant.OrderManagement.model.Item;

public interface ItemService {

	List<Item> findAll();
	
	Item findById(Integer id);
}
