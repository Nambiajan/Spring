import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import {Order} from '../order';
import 'rxjs/Rx';
import { Cart } from '../cart';
@Injectable({
  providedIn: 'root'
})
export class CartService {

  allOrdersUrl="http://localhost:8080/cart/all-order";
  allCartUrl="http://localhost:8080/cart/cart";
  deleteOrderUrl="http://localhost:8080/cart/deleteorder";
  constructor(private http:Http) { }

  getAllOrders():Observable<Order[]>{

    console.log("cartService");
    return this.http.get(this.allOrdersUrl)
          .map(this.extractData)
          .catch(this.handleError);
  
   
    }
    deleteOrder(id:number)
    {
      let cpHeaders = new Headers({'Content-type':'application/json'});
      let options = new RequestOptions({headers:cpHeaders});
      
     return this.http.post(this.deleteOrderUrl,id,options).map(success => success.status).catch(this.handleError);
   
    }

    getTotal():Observable<number>{

      console.log("cartService");
      return this.http.get(this.allCartUrl)
            .map(this.extractData)
            .catch(this.handleError);
    
     
      }
    private extractData(res: Response) {
      let body = res.json();
        return body;
    }
    private handleError (error: Response | any) {
      console.error(error.message || error);
      return Observable.throw(error.status);
      }

}
