import { Component, OnInit } from '@angular/core';
import {Order} from '../order';
import { CartService } from './cart.service';
import { Cart } from '../cart';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private cartService:CartService) { }

  orders :Order[];
  cart : Cart;
  total :number;
  statusCode:number;
  ngOnInit() {
    this.getAllOrders();
    this.getTotal();
    
  }
  getAllOrders()
  {
      console.log("cartcomponent");
     this.cartService.getAllOrders()
          .subscribe(
            data=>this.orders= data,
            errorCode=>this.statusCode=errorCode);
          
  }
  getTotal()
  {
       this.cartService.getTotal()
             .subscribe(
                     data=>this.total= data,
                      errorCode=>this.statusCode=errorCode);
  }
  deleteOrder(id:number)
  {
     console.log("sdadsadasda"+id);
     this.cartService.deleteOrder(id)
                  .subscribe(successCode => {
                        this.statusCode = successCode;});

        this.ngOnInit();
  }
   
}
