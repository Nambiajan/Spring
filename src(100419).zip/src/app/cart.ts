import { Order } from './order';

export class Cart {
    constructor(public cart_id?:number,public orders?:Order[],public total?:number){}
}
