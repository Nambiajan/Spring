import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import {User} from '../user';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { map } from "rxjs/operators"; 

@Injectable({
  providedIn: 'root'
})
export class UserregService {

   regUserUrl="http://localhost:8080/user/register";
  constructor(private http:Http) { }
  register(user:User):Observable<number>
  {
         let cpHeaders = new Headers({'Content-type':'application/json'});
         let options = new RequestOptions({headers:cpHeaders});
         return this.http.post(this.regUserUrl,user,options).map(success => success.status).catch(this.handleError);
            
                 
                
  }
   private handleError (error: Response | any) {
		console.error(error.message || error);
		return Observable.throw(error.status);
    }
}
