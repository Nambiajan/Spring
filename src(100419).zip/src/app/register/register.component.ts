import { Component, OnInit } from '@angular/core';
import {User} from '../user';
import {UserregService} from './userreg.service';
import { RouterModule, Routes} from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  statusCode:number;
  
  constructor(private userRegService:UserregService,private router: Router) { }

  ngOnInit() {
  }
  userModel = new User();
  onSubmit()
  {
      if(this.userModel.cpassword!=this.userModel.password)
                     {
                       this.userModel.cpassword="";
                       this.userModel.password="";
                       this.statusCode=203;
                       return;
                     }
    this.userRegService.register(this.userModel)
        .subscribe(successCode => {
		            this.statusCode = successCode;
                 if(this.statusCode==201)
                  {
                       this.router.navigate(['/home']);
                  }
                  else if(this.statusCode==202)
                  {
                     this.userModel.username="";
                    
                  }
        },
          errorCode => this.statusCode = errorCode
        );

       
  }

}
