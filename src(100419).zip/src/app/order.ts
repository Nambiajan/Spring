import {Item} from './item';
export class Order {
    constructor(public id?:number,public quantity?:number,public item?:Item,public tprice?:number){}
}
