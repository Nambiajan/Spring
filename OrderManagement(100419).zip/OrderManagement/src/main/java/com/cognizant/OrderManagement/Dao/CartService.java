package com.cognizant.OrderManagement.Dao;

import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;

public interface CartService {
	
	Cart findById(Integer id);
	
	void save (Cart cart);
	
	void addToCart(Item item);

	void updateCart(Integer id);

}
