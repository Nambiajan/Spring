package com.cognizant.OrderManagement.Dao;

import java.util.List;

import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.model.UserOrder;

public interface OrderService {

	

	UserOrder addOrder(Item item);

	void findOrder(Cart cart, Item item);

    List<UserOrder> findAll();
    
    void deleteOrder(Integer id);

	

}
