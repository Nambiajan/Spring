package com.cognizant.OrderManagement.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService{

	@Autowired
	private ItemRepository itemRepository;
	
	
	@Override
	public List<Item> findAll()
	{
		return itemRepository.findAll();
	}


	@Override
	public Item findById(Integer id) {
		// TODO Auto-generated method stub
		return itemRepository.findById(id).get();
	}
}
