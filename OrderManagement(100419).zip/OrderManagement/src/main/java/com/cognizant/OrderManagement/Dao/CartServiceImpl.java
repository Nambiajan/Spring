package com.cognizant.OrderManagement.Dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.model.UserOrder;
import com.cognizant.OrderManagement.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	CartRepository cartRepository;
	@Autowired
	private ItemService itemService;
	@Autowired
	private OrderService orderService;
	
	
	public Cart findById(Integer id)
	{
		
		return cartRepository.getOne(id);
	}

	@Override
	public void save(Cart cart) {
		// TODO Auto-generated method stub
		cartRepository.save(cart);
	}

	@Override
	public void addToCart(Item i) {
		// TODO Auto-generated method stub
		  Cart cart = findById(1);
		  System.out.println("sizeeeeeeeeeeeeeeeeeeeeeeeeeeee");
		  System.out.println(cart.getOrders().size()+"   hhhhhhhhhhhhhh");
		  if(cart.getOrders().size()==0)
		  {
			 cart.getOrders().add(orderService.addOrder(i));
		  }
		  else
		  {
			 orderService.findOrder(cart,i);
			 
		  }
		  
		  calculateTotal(cart);
		
		  save(cart);
		 
	}
	void calculateTotal(Cart cart)
	{
		    cart.setTotal(0);
		for(UserOrder o :cart.getOrders())
		  {
			  cart.setTotal(cart.getTotal()+o.getTprice());
		  }
	}

	@Override
	public void updateCart(Integer id) {
		// TODO Auto-generated method stub
		Cart cart = findById(1); 
		orderService.deleteOrder(id);
		calculateTotal(cart);
		save(cart);
	}
	


}
