package com.cognizant.OrderManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriComponentsBuilder;

import com.cognizant.OrderManagement.Dao.CartService;
import com.cognizant.OrderManagement.Dao.ItemService;
import com.cognizant.OrderManagement.Dao.OrderService;
import com.cognizant.OrderManagement.model.Item;


@Controller
@RequestMapping("menu")
@CrossOrigin(origins = {"http://localhost:4200"})
public class OrderController {

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private CartService cartService;
	
	
	
	@GetMapping("all-item")
	public ResponseEntity<List<Item>> getAllItems() {
		List<Item> list = itemService.findAll();
		System.out.println("***************************");
		for(Item i:list)
		{  
			
			System.out.println(i.getName());
			
		}
		return new ResponseEntity<List<Item>>(list, HttpStatus.OK);
	}
	
	@PostMapping("addtocart")
	public ResponseEntity<Void> addToCart(@RequestBody Item item, UriComponentsBuilder builder) {
        
       System.out.println("dfffffffffffffffffffffffffffffffffffffffffffffffffff");
        System.out.println(item.getId());
        System.out.println(item.getQuantity());
         cartService.addToCart(item);
        HttpHeaders headers = new HttpHeaders();
        //headers.setLocation(builder.path("/article?id={id}").buildAndExpand(article.getArticleId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
}
