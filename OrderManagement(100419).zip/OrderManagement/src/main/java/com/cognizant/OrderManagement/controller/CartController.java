package com.cognizant.OrderManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriComponentsBuilder;

import com.cognizant.OrderManagement.Dao.CartService;
import com.cognizant.OrderManagement.Dao.OrderService;
import com.cognizant.OrderManagement.model.Cart;
import com.cognizant.OrderManagement.model.Item;
import com.cognizant.OrderManagement.model.UserOrder;

@Controller
@RequestMapping("cart")
@CrossOrigin(origins = {"http://localhost:4200"})
public class CartController {
    
	@Autowired 
	private OrderService orderService;
	@Autowired
	private CartService cartService;
	@GetMapping("all-order")
	public ResponseEntity<List<UserOrder>> getAllItems() {
		//
		System.out.println("***************************ooooooooooooooooooo");
		
		List<UserOrder> list = orderService.findAll();
		System.out.println(list.size());
		return new ResponseEntity<List<UserOrder>>(list, HttpStatus.OK);
	}
	@GetMapping("cart")
	public ResponseEntity<Integer> getCart() {
		//
		System.out.println("***************************ccccccccccccccccccc");
		
		Cart cart = cartService.findById(1);
		//System.out.println(cart.getOrders().size()+"sssssssssssssssss");
		return new ResponseEntity<Integer>(cart.getTotal(), HttpStatus.OK);
		//return null;
	}@PostMapping("deleteorder")
	public ResponseEntity<Void> deleteFromCart(@RequestBody Integer id, UriComponentsBuilder builder) {
        
		   
	        cartService.updateCart(id); 
	        HttpHeaders headers = new HttpHeaders();
	        //headers.setLocation(builder.path("/article?id={id}").buildAndExpand(article.getArticleId()).toUri());
	        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
		}
	
	
}
