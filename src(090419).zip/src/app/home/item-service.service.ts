import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';


import { Item } from '../item';
import 'rxjs/Rx';

@Injectable({
  providedIn: 'root'
})
export class ItemServiceService {

  allItemsUrl="http://localhost:8080/menu/all-item";
  addToCartUrl="http://localhost:8080/menu/addtocart"
  citem:Item;
  constructor(private http:Http) { }

  getAllItems():Observable<Item[]>{

      return this.http.get(this.allItemsUrl)
            .map(this.extractData)
            .catch(this.handleError);
    
     
      }

      private extractData(res: Response) {
        let body = res.json();
          return body;
      }
      addToCart(id:number,q:number):Observable<number>
  {      
       console.log("AddtoCart");
         this.citem=new Item(id,q);
         console.log(this.citem.id);
         console.log(this.citem.quantity);
         let cpHeaders = new Headers({'Content-type':'application/json'});
         let options = new RequestOptions({headers:cpHeaders});
         
        return this.http.post(this.addToCartUrl,this.citem,options).map(success => success.status).catch(this.handleError);
      
                 
                
  }
      private handleError (error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.status);
        }

  }

