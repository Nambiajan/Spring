import { Component, OnInit } from '@angular/core';
import {Item} from '../item';
import {ItemServiceService} from './item-service.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

   items : Item[];
   citem:Item;
   statusCode:number;
  constructor(private itemService:ItemServiceService) { }

  ngOnInit() {
    this.getAllItems();
  }
  
  getAllItems()
  {
     this.itemService.getAllItems()
          .subscribe(
            data=>this.items= data,
            errorCode=>this.statusCode=errorCode);
          
  }
  onAdd(id:number,q:number)
  {
       console.log("onAdd");
       this.itemService.addToCart(id,q)
          .subscribe(successCode => {
            this.statusCode = successCode;});
       
  }
}
