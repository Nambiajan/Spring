export class Item {
    constructor(public id?:number,public quantity?:number,public name?:string,public price?:number){}
}
