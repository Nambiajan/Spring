import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { RegisterComponent } from './register/register.component';
import {FormsModule} from '@angular/forms';
import {UserregService} from './register/userreg.service';
import {AuthService} from './auth.service';
import {ItemServiceService} from './home/item-service.service';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { HttpModule } from '@angular/http';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    CartComponent,
  
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    HttpModule
  ],
  providers: [UserregService,ItemServiceService,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
